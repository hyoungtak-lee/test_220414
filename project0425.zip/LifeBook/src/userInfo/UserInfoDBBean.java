package userInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

public class UserInfoDBBean {
	private static UserInfoDBBean instance=new UserInfoDBBean();
	public static UserInfoDBBean getInstance() {
		return instance;
	}
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	public int insertMember(UserInfoBean member) throws Exception { //ȸ������
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="insert into userinfo values(?,?,?,?,?,?,?,?)";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getUser_id());
			pstmt.setString(2, member.getUser_pwd());
			pstmt.setString(3, member.getUser_phonenumber());
			pstmt.setString(4, member.getUser_address());
			pstmt.setTimestamp(5, member.getUser_birthdate());
			pstmt.setInt(6, member.getUser_mileage());
			pstmt.setInt(7, member.getAdminYN());
			pstmt.setString(8, member.getUser_name());
			pstmt.executeUpdate();
			
			re=1;
 			pstmt.close();
 			conn.close();
 			
			System.out.println("�߰� ����");
		} catch (Exception e) {
			System.out.println("�߰� ����");
			e.printStackTrace();
		}
		
		return re;
	}
	
	public int confirmID(String id) throws Exception{ //���Ե� ���̵����� Ȯ��
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select user_id from userinfo where user_id=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) { //�̹� �ִ� ���̵�
 				re=1;
			}else { //���� ���̵�
				re=-1;
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return re;
	}
	
	public int userCheck(String id, String pwd) throws Exception{ //���̵�� ��й�ȣ�� �´��� Ȯ��
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select user_pwd from userinfo where user_id=?";
		int re=-1;
		String db_user_pwd;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
 			rs = pstmt.executeQuery();
 			
 			if(rs.next()) {
 				db_user_pwd = rs.getString("user_pwd");
 				
 				if (db_user_pwd.equals(pwd)) {
					re=1;
				}else {
					re=0;
				}
 			}else {
 				re=-1;
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return re;
	}
	
	public UserInfoBean getMember(String id) throws Exception{ //ȸ������ ��������
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select user_id, user_pwd, user_phonenumber, user_address, user_birthdate, user_mileage, adminYN, user_name from userinfo where user_id=?";
		UserInfoBean member=null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) {
				member = new UserInfoBean();
				member.setUser_id(rs.getString("user_id"));
				member.setUser_pwd(rs.getString("user_pwd"));
				member.setUser_phonenumber(rs.getString("user_phonenumber"));
				member.setUser_address(rs.getString("user_address"));
				member.setUser_birthdate(rs.getTimestamp("user_birthdate"));
				member.setUser_mileage(rs.getInt("user_mileage"));
				member.setAdminYN(rs.getInt("adminYN"));
				member.setUser_name(rs.getString("user_name"));
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return member;
	}
	
	public int updateMember(UserInfoBean member) throws Exception { //ȸ������ ����
		Connection conn=null;
		PreparedStatement pstmt=null;
		int re=-1;
		
		String sql="update userinfo set user_pwd=?, user_phonenumber=?, user_address=?, user_birthdate=? where user_id=?";
		
		try {
			conn=getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getUser_pwd());
			pstmt.setString(2, member.getUser_phonenumber());
			pstmt.setString(3, member.getUser_address());
			pstmt.setTimestamp(4, member.getUser_birthdate());
			pstmt.setString(5, member.getUser_id());
			re = pstmt.executeUpdate();
			
			System.out.println("���� ����");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("���� ����");
		}
		
		return re;
	}
	
	public int deleteMember(String user_id, String user_pwd) { //ȸ��Ż��
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		String pwd="";
		int re=-1;
		
		try {
			conn = getConnection();
			sql="select user_pwd from userinfo where user_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				pwd = rs.getString(1);
				if (pwd.equals(user_pwd)) { //�н����尡 ������ Ż���Ű�鼭 ȸ������ ����
					sql="delete from userinfo where user_id=?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, user_id);
					pstmt.executeUpdate();
					re=1;
				}else { //�н����尡 �ٸ��� Ż�����
					re=0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public int registerIdCheck(String user_id) { //���̵� �ߺ�üũ
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		int result = -1;
		
		try {
			conn = getConnection();
			sql=("select user_id from userinfo where user_id=?");
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_id);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) { //�̹� �����ϴ� ���̵�
				result = 0;
			}else {
				result = 1;
			}
			
			System.out.println("���̵� �ߺ�üũ��� :"+"result");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return result;
	}
	
	public String findId(String user_name, String user_phonenumber) { //���̵� ã�� �޼ҵ�
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		String uid = null; //���Ϲ��� �������̵�
		
		try {
			conn = getConnection();
			sql = "select user_id from userinfo where user_name=? and user_phonenumber=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_name);
			pstmt.setString(2, user_phonenumber);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				uid = rs.getString("user_id");
			}
		} catch (Exception e) {
				e.printStackTrace();
		}
		return uid;
	}
	
	public String findPwd(String user_name, String user_id, String user_phonenumber) { //��й�ȣ ã�� �޼ҵ�
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		String pwd = null; //���Ϲ��� ������й�ȣ
		
		try {
			conn = getConnection();
			sql = "select user_pwd from userinfo where user_name=? and user_id=? and user_phonenumber=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user_name);
			pstmt.setString(2, user_id);
			pstmt.setString(3, user_phonenumber);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				pwd = rs.getString("user_pwd");
			}
		} catch (Exception e) {
				e.printStackTrace();
		}
		return pwd;
	}
	
	public static void makeCookie(HttpServletResponse response, String cName, String cValue, int cTime) {
		Cookie cookie = new Cookie(cName, cValue);  //���� ����
		cookie.setPath("/");                        //��� ����
		cookie.setMaxAge(cTime);                    //���� �Ⱓ ����
		response.addCookie(cookie);                 //���� ��ü�� �߰�
	}
	
	//������ �̸��� ��Ű�� ã�� �� ���� ��ȯ��.
	public static String readCookie(HttpServletRequest request, String cName) {
		String cookieValue = "";
		
		Cookie[] cookies = request.getCookies();  //Ŭ���̾�Ʈ�� ������ ��Ű ����� �޾Ƽ�
		if (cookies != null) {   //��Ű�� �����Ѵٸ�
			for(Cookie c : cookies) {
				String cookieName = c.getName();
				if (cookieName.equals(cName)) {   //���� cName�� �̸��� ���� ��Ű�� �ִٸ�
					cookieValue = c.getValue();   //��ȯ ���� �����Ѵ�
				}
			}
		}
		return cookieValue;   //�� ���� ��ȯ��.
	}
	
	//������ �̸��� ��Ű�� ������.
	public static void deleteCookie(HttpServletResponse response, String cName) {
		makeCookie(response, cName, "", 0);     //����ִ� ���ڿ��� ��Ű ����, ���� �Ⱓ�� 0���� �ο���
	}
}
