package order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class OrderDBBean {

	private static OrderDBBean instance = new OrderDBBean();
	
	//OrderDBBean��ü ����
	public static OrderDBBean getInstance(){
		return instance;
	}
	
	//DBCP ��ü ����
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:/comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	//�ֹ����̺��� �ֹ����� �����ϴ� �޼ҵ�
	public int insertOrder(OrderBean order) {
		String insertQuery = "insert into order_table(ordernum, userid, booknum, orderrecipient, orderphonenum, orderaddr, amount) values(?,?,?,?,?,?,?)";
		int re = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setString(1, order.getOrderNum());
			System.out.println(order.getOrderNum());
			pstmt.setString(2, order.getUserID());
			System.out.println(order.getUserID());
			pstmt.setInt(3, order.getBookNum());
			System.out.println(order.getBookNum());
			pstmt.setString(4, order.getOrderRecipient());
			System.out.println(order.getOrderRecipient());
			pstmt.setString(5, order.getOrderPhoneNum());
			System.out.println(order.getOrderPhoneNum());
			pstmt.setString(6, order.getOrderAddr());
			System.out.println(order.getOrderAddr());
			pstmt.setInt(7, order.getAmount());
			System.out.println(order.getAmount());
			
			re = pstmt.executeUpdate();//���� ������ re=1�� ��
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	
	//��� �ֹ������� �������� ���̺�
	public ArrayList<OrderBean> getAllOrder() {
		String selectQuery = "select * from order_table";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<OrderBean> orders = null;
		OrderBean order = null;
		
		try {
			orders = new ArrayList<OrderBean>();
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				order = new OrderBean();
				
				order.setOrderNum(rs.getString(1));
				order.setUserID(rs.getString(2));
				order.setBookNum(rs.getInt(3));
				order.setAmount(rs.getInt(4));
				order.setOrderDate(rs.getTimestamp(5));
				
				orders.add(order);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return orders;
	}
	
	//�ֹ������� �Ű������� �ֹ������� �������� �޼ҵ�
	public OrderBean getOrder(String orderNum) {
		String selectQuery = "select * from order_table where ordernum=?";
		OrderBean order = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, orderNum);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				order = new OrderBean();
				order.setOrderNum(rs.getString(1));
				order.setUserID(rs.getString(2));
				order.setBookNum(rs.getInt(3));
				order.setOrderDate(rs.getTimestamp("orderdate"));
				order.setAmount(rs.getInt("amount"));
				order.setStatement(rs.getString("STATEMENT"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return order;
	}
	
	//���̵� �Ű������� �޾Ƽ� �ش� ���̵� �ش��ϴ� �ֹ������� �޾ƿ��� �޼ҵ�
	public ArrayList<OrderBean> getMyOrder(String userID){
		String selectQuery = "select ordernum, userid, booknum, amount, orderdate, orderaddr, orderphonenum, statement from order_table where userID=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<OrderBean> orders = null;
		OrderBean order = null;
		
		try {
			orders = new ArrayList<OrderBean>();
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, userID);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				order = new OrderBean();
				
				order.setOrderNum(rs.getString(1));
				order.setUserID(rs.getString(2));
				order.setBookNum(rs.getInt(3));
				order.setAmount(rs.getInt(4));
				order.setOrderDate(rs.getTimestamp(5));
				order.setOrderAddr(rs.getString(6));
				order.setOrderPhoneNum(rs.getString(7));
				order.setStatement(rs.getString(8));
				
				orders.add(order);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return orders;
	}
	
	//�־�� �� �ֹ���ȣ�� �����ϴ� �޼ҵ�
	public long getTodayOrderNumber() {
		String selectQuery = "select count(*) from order_table where to_char(orderdate,'yymmdd') = to_char(sysdate,'yymmdd')";
		long num = 0;
		
		//���� ��¥�� �ֹ���ȣ ���� ����
		LocalDateTime now = LocalDateTime.now();
		String pattenOfOrderNum = DateTimeFormatter.ofPattern("yyMMdd0000").format(now);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				num = Long.parseLong(pattenOfOrderNum) + rs.getInt(1) + 1;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return num;
	}
	public int updateOrderStatement(String orderNum, String statement) {
		String updateQuery = "update order_table set statement=? where ordernum=?";
		int re = -1; // �������� �� ������ ����
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(updateQuery);
			pstmt.setString(1, statement);
			pstmt.setString(2, orderNum);
			
			re = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
}
