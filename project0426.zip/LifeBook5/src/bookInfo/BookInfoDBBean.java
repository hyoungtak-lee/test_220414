package bookInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class BookInfoDBBean {
	private static BookInfoDBBean instance = new BookInfoDBBean();
	
	//��ü�� �������ִ� �޼ҵ�
	public static BookInfoDBBean getInstance(){
		return instance;
	}
	
	//dbcp��ü�� �������ִ� �޼ҵ�
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:/comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	//Database�� å ������ �߰��ϴ� �޼ҵ�
	public int insertBookInfo(BookInfoBean book) {//������ ����
		String insertQuery = "insert into bookinfo values(?,?,?,?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		int re = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1, book.getBookNum());
			pstmt.setString(2, book.getBookName());
			pstmt.setString(3, book.getBookDetails());
			pstmt.setInt(4, book.getBookPrice());
			pstmt.setString(5, book.getBookPub());
			pstmt.setString(6, book.getAuthor());
			pstmt.setString(7, book.getBookImg());
			pstmt.setInt(8, book.getBookStock());

			re = pstmt.executeUpdate();
			
			re = 1;
			pstmt.close();
			conn.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return re;
	}
	
	//å ��ȣ�� �������� �޼ҵ�
	public int getCategoryNumber(String str_category){
		int category = Integer.parseInt(str_category+"00000");
		String selectQuery = "select count(*) from bookinfo where booknum >= ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int re = 0;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			
			pstmt.setInt(1, category);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				re = category + rs.getInt(1) + 1;
			}
		} catch (Exception se) {
			se.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return re;
	}
	
	//DB���� å�� ������ �������� �޼ҵ�
	public ArrayList<BookInfoBean> getBookList(int page, String category){
		String selectQuery = "select * from bookinfo where booknum between ? and ? and rownum<?";
		String minCategory = category + "00000";
		String maxCategory = category + "99999";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<BookInfoBean> books = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, minCategory);
			pstmt.setString(2, maxCategory);
			pstmt.setInt(3, page*10);
			
			rs = pstmt.executeQuery();
			books = new ArrayList<BookInfoBean>();
			
			while (rs.next()) {
				BookInfoBean book = new BookInfoBean();
				
				book.setBookNum(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookDetails(rs.getString(3));
				book.setBookPrice(rs.getInt(4));
				book.setBookPub(rs.getString(5));
				book.setAuthor(rs.getString(6));
				book.setBookImg(rs.getString(7));
				book.setBookStock(rs.getInt(8));
				
				books.add(book);
			}
		} catch (Exception se) {
			se.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return books;
	}
	
	//�˻�� �Ű������� �޾Ƽ� �ش� �˻�� �ش�Ǵ� �����͸� �����ϴ� �޼ҵ�
	public ArrayList<BookInfoBean> searchBookList(String search){
		String selectQuery = "select * from bookinfo where booknum like ? or author like ?";
		search = "%"+search+"%";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<BookInfoBean> books = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, search);
			pstmt.setString(2, search);
			
			rs = pstmt.executeQuery();
			books = new ArrayList<BookInfoBean>();
			
			while (rs.next()) {
				BookInfoBean book = new BookInfoBean();
				
				book.setBookNum(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookDetails(rs.getString(3));
				book.setBookPrice(rs.getInt(4));
				book.setBookPub(rs.getString(5));
				book.setAuthor(rs.getString(6));
				book.setBookImg(rs.getString(7));
				book.setBookStock(rs.getInt(8));
				
				books.add(book);
			}
		} catch (Exception se) {
			se.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return books;
	}
	
	//�ϳ��� å������ �����͸� �������� �޼ҵ�
	public BookInfoBean getBookInfo(int bookNum){
		String selectquery = "select * from bookinfo where booknum=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BookInfoBean book = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectquery);
			pstmt.setInt(1, bookNum);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				book = new BookInfoBean();
				book.setBookNum(rs.getInt(1));
				book.setBookName(rs.getString(2));
				book.setBookDetails(rs.getString(3));
				book.setBookPrice(rs.getInt(4));
				book.setBookPub(rs.getString(5));
				book.setAuthor(rs.getString(6));
				book.setBookImg(rs.getString(7));
				book.setBookStock(rs.getInt(8));
			}
		} catch (Exception se) {
			se.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return book;
	}
}
