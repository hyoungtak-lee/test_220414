package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class managementMemberDBBean {
private static managementMemberDBBean instance = new managementMemberDBBean();
	
	public static managementMemberDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	//ȸ����� �ҷ����� �޼���
//	public ArrayList<managementMemberBean> listMember(){
//		ArrayList<managementMemberBean> list = new ArrayList<managementMemberBean>();
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		String sql = "select * from test1";
//		
//		try {
//			con = getConnection();
//			pstmt = con.prepareStatement(sql);
//			rs = pstmt.executeQuery();
//			
//			while (rs.next()) {
//				managementMemberBean member = new managementMemberBean();
//				member.setUser_id(rs.getString("user_id"));
//				member.setUser_pwd(rs.getString("user_pwd"));
//				member.setUser_tel(rs.getInt("user_tel"));
//				member.setUser_phonenumber(rs.getInt("user_phonenumber"));
//				member.setUser_address(rs.getString("user_address"));
//				member.setUser_birthdate(rs.getDate("user_birthday"));
//				
//				list.add(member);
//			}
//			rs.close();
//            pstmt.close();
//            con.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return list;
//	}
	//������ ȸ������ �ҷ����� �޼���
	public managementMemberBean getMember(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		managementMemberBean member = new managementMemberBean();
		String sql = "select * from userinfo where user_id=?";
		
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				member.setUser_id(rs.getString("user_id"));
				member.setUser_pwd(rs.getString("user_pwd"));
				member.setUser_name(rs.getString("user_name"));
				member.setUser_tel(rs.getInt("user_tel"));
				member.setUser_phonenumber(rs.getInt("user_phonenumber"));
				member.setUser_address(rs.getString("user_address"));
				member.setUser_birthdate(rs.getTimestamp("user_birthdate"));				
			}
			rs.close();
            pstmt.close();
            con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return member;
	}
	//ȸ������ ������Ʈ �޼���
	public int updateMember(managementMemberBean member) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update userinfo set user_tel=?, user_phonenumber=?, user_address=?, user_name=? where user_id=?";
		int re =-1;
		
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, member.getUser_tel());
			pstmt.setInt(2, member.getUser_phonenumber());
			pstmt.setString(3, member.getUser_address());
			pstmt.setString(4, member.getUser_name());
			pstmt.setString(5, member.getUser_id());
			pstmt.executeUpdate();
			re=1;
			
			pstmt.close();
            con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return re;
	}
	//ȸ������ ���� �޼���
	public int deleteMemberAdmin(String user_id, String user_pwd) {
	Connection con = null;
	PreparedStatement pstmt = null;
//	ResultSet rs = null;
//	String id="";
//	String pwd="";
	String sql = "delete from userinfo where user_id=? and user_pwd=?";
	int re=-1;
	
	try {
		con = getConnection();
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, user_id);
		pstmt.setString(2, user_pwd);
		pstmt.executeUpdate();
		re=1;
		
		pstmt.close();
        con.close();
        //rs.close();
	} catch (Exception e) {
		e.printStackTrace();
	}
	return re;
}
}
