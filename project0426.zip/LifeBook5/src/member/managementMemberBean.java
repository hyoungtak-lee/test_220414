package member;

import java.sql.Timestamp;

public class managementMemberBean {
	String user_id;
	String user_pwd;
	String user_name;
	int user_tel;
	int user_phonenumber;
	String user_address;
	Timestamp user_birthdate;
	int user_mileage;
	int adminyn;
	
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public int getUser_tel() {
		return user_tel;
	}
	public void setUser_tel(int user_tel) {
		this.user_tel = user_tel;
	}
	public int getUser_phonenumber() {
		return user_phonenumber;
	}
	public void setUser_phonenumber(int user_phonenumber) {
		this.user_phonenumber = user_phonenumber;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public Timestamp getUser_birthdate() {
		return user_birthdate;
	}
	public void setUser_birthdate(Timestamp user_birthdate) {
		this.user_birthdate = user_birthdate;
	}
	public int getUser_mileage() {
		return user_mileage;
	}
	public void setUser_mileage(int user_mileage) {
		this.user_mileage = user_mileage;
	}
	public int getAdminyn() {
		return adminyn;
	}
	public void setAdminyn(int adminyn) {
		this.adminyn = adminyn;
	}
}
