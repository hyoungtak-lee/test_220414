function check_ok(){
	if(mana_form.user_phonenumber.value.legth==0){
		alert("휴대폰번호를 입력하세요");
		mana_form.user_phonenumber.focus();
		return;
	}
	if(mana_form.user_address.value.legth==0){
		alert("주소를 입력하세요");
		mana_form.user_address.focus();
		return;
	}
	mana_form.submit();
}