function check_ok(){
	
	if(reg_frm.userID.value.length == 0){
		alert("ID를 써주세요.");
		reg_frm.userID.focus();
		return;
	}
	
	if(reg_frm.userPWD.value.length == 0){
		alert("패스워드는 반드시 입력해야 합니다.");
		reg_frm.userPWD.focus();
		return;
	}
	
	if(reg_frm.userPWD_check.value != reg_frm.userPWD.value){
		alert("패스워드가 일치하지 않습니다.");
		reg_frm.userPWD_check.focus();
		return;
	}
	
	if(reg_frm.user_tel2.value.length == 0){
		alert("전화번호를 써주세요.");
		reg_frm.user_tel2.focus();
		return;
	}
	
	if(reg_frm.user_tel3.value.length == 0){
		alert("전화번호를 써주세요.");
		reg_frm.user_tel3.focus();
		return;
	}
	
	if(reg_frm.userAddr.value.length == 0){
		alert("주소를 써주세요.");
		reg_frm.userAddr.focus();
		return;
	}
	
	if(reg_frm.userBirth.value.length != 6 ){
		alert("주민번호 앞자리를 써주세요.");
		reg_frm.userBirth.focus();
		return;
	}
	
	document.reg_frm.submit();
}

function modify_check_ok(){
	if(document.mod_frm.userPWD.value.length == 0){
		alert("패스워드는 반드시 입력해야 합니다.");
		mod_frm.userPWD.focus();
		return;
	}	
	
	if(document.mod_frm.userPWD.value != mod_frm.userPWD_check.value){
		alert("패스워드가 일치하지 않습니다.");
		mod_frm.userPWD_check.focus();
		return;
	}
		
	document.mod_frm.submit();
}

function withdraw_ok(){
	if(reg_frm.userPWD.value.length == 0){
		alert("비밀번호를 써주세요.");
		reg_frm.userPWD.focus();
		return;
	}
		
	document.reg_frm.submit();
}
