package userInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class UserInfoDBBean {
	
	private static UserInfoDBBean instance=new UserInfoDBBean();
	
	public static UserInfoDBBean getInstance() {
		return instance;
	}
	
	//dbcp ��ü����
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	//userinfo�� �����͸� �ִ� �޼ҵ�
	public int insertUser(UserInfoBean user) {
		String sql="insert into userinfo values(?,?,?,?,?,?,?,?)";
		int re=-1;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUserID());
			pstmt.setString(2, user.getUserPWD());
			pstmt.setString(3, user.getUserPhoneNum());
			pstmt.setString(4, user.getUserAddr());
			pstmt.setTimestamp(5, user.getUserBirth());
			pstmt.setInt(6, 0);
			pstmt.setInt(7, user.getIsAdmin());
			pstmt.setString(8, user.getUserName());
			
			pstmt.executeUpdate();
			
			re=1;
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	//���Ե� ���̵����� Ȯ���ϴ� �޼ҵ�
	public int confirmID(String userID) { 
		String sql = "select userID from userinfo where userID=?";
		int re = -1;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) { //�̹� �ִ� ���̵��� ���
 				re = 1;
			}else { //���� ���̵��� ���
				re = -1;
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
				
			}
		}
		
		return re;
	}
	
	//���̵�� ��й�ȣ�� �´��� Ȯ��
	public int userCheck(String userID, String userPWD){ 
		String sql = "select userpwd from userinfo where userid=?";
		int re = -1;
		String db_userPWD;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			
 			rs = pstmt.executeQuery();
 			
 			if(rs.next()) {
 				db_userPWD = rs.getString("userPWD");
 				
 				if (db_userPWD.equals(userPWD)) { // �Ű����� pwd�� db���� �����°��� ������ �˻�
					re = 1;
				}else {
					re = 0;
				}
 			}else {
 				re=-1;
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
				
			}
		}
		
		return re;
	}
	
	//���ǿ� ������ id���� �Ű������� ���� ������ �������� �޼ҵ�
	public UserInfoBean getUser(String userID){
		String sql="select userid, userpwd, userphonenum, useraddr, userbirth, point, isadmin, username from userinfo where userid=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserInfoBean user = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) {
 				user = new UserInfoBean();
 				
 				user.setUserID(rs.getString("userID"));
 				user.setUserPWD(rs.getString("userPWD"));
 				user.setUserPhoneNum(rs.getString("userPhoneNum"));
 				user.setUserAddr(rs.getString("userAddr"));
 				user.setUserBirth(rs.getTimestamp("userBirth"));
 				user.setPoint(rs.getInt("Point"));
 				user.setIsAdmin(rs.getInt("isAdmin"));
 				user.setUserName(rs.getString("userName"));
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return user;
	}
	
	//ȸ�������� �����ϴ� �޼ҵ�
	public int updateUser(UserInfoBean user) {
		String sql="update userinfo set userpwd=?, useraddr=?, userphonenum=? where userid=?";
		int re=-1;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		try {
			conn=getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUserPWD());
			pstmt.setString(2, user.getUserAddr());
			pstmt.setString(3, user.getUserPhoneNum());
			pstmt.setString(4, user.getUserID());
			
			re = pstmt.executeUpdate();
			
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	//ȸ�������� �����ϴ� �޼ҵ�
	public int deleteUser(String userID, String userPWD) {
		String sql = "";
		String pwd = "";
		int re = -1;
		System.out.println("ID=>"+userID);
		System.out.println("PW=>"+userPWD);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			System.out.println("try������");
			conn = getConnection();
			sql = "select userpwd from userinfo where userid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			
			rs = pstmt.executeQuery();
			System.out.println("���� ����");
			if(rs.next()) {
				System.out.println("if������");
				pwd = rs.getString(1);
				pstmt.close();
				
				if (pwd.equals(userPWD)) {
					System.out.println("2�� if������");
					sql="delete from userinfo where user_id=?";
					
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, userID);
					
					pstmt.executeUpdate();
					
					re = 1;
				}else {
					re = 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		System.out.println(re);
		return re;
	}
	
	//�����ڸ� 1, �Ϲ�ȸ���̸� 0�� �����ϴ� �޼ҵ�
	public int getAdminYN(String userID) {
		String sql="select isadmin from userinfo where userid=?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int adminYN = 0;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) {
 				adminYN = rs.getInt(1);
 			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return adminYN;
	}
	
	public int registerIdCheck(String userID) { //���̵� �ߺ�üũ
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		int result = -1;
		
		try {
			conn = getConnection();
			sql=("select userid from userinfo where userid=?");
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userID);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) { //�̹� �����ϴ� ���̵�
				result = 0;
			}else {
				result = 1;
			}
			
			System.out.println("���̵� �ߺ�üũ��� :"+"result");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return result;
	}
	
	public String findId(String userName, String userPhoneNum) { //���̵� ã�� �޼ҵ�
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		String uid = null; //���Ϲ��� �������̵�
		
		try {
			conn = getConnection();
			sql = "select userid from userinfo where username=? and userphonenum=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setString(2, userPhoneNum);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				uid = rs.getString("userID");
			}
		} catch (Exception e) {
				e.printStackTrace();
		}
		return uid;
	}
	
	public String findPwd(String userName, String userID, String userPhoneNum) { //��й�ȣ ã�� �޼ҵ�
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="";
		String pwd = null; //���Ϲ��� ������й�ȣ
		
		try {
			conn = getConnection();
			sql = "select userpwd from userinfo where username=? and userid=? and userphonenum=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setString(2, userID);
			pstmt.setString(3, userPhoneNum);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				pwd = rs.getString("userPWD");
			}
		} catch (Exception e) {
				e.printStackTrace();
		}
		return pwd;
	}
}
