package lifeBookBoard;

import java.sql.Timestamp;

public class BoardBean {
	private String user_id;
	private String b_title;
	private String b_content;
	private int b_number;
	private int b_hit;
	private Timestamp b_date;
	private int b_push;
	private String b_fname;
	private int b_fsize;
	private String b_rfname;
	private String b_ip;
	
	public static int pageSize = 10;
	public static int pageCount = 1;
	public static int pageNum = 1;
	
	public static String pageNumber(int limit) {
		String str = "";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		
		// [prev page] ��ư ���
		if ((startPage - limit) > 0) {
			str = "<a href='list.jsp?pageNum=" + (startPage - 1) + "'>����</a>&nbsp;&nbsp;";
		}
		
		// ������ ��ȣ ����
		for (int i = startPage; i < (startPage + limit); i++) {
			if (i == pageNum) {
				str += i + "&nbsp;&nbsp;";
			} else {
				str += "<a href='list.jsp?pageNum=" + i + "'>" + i + "</a>&nbsp;&nbsp;";
			}
			if(i >= pageCount) break;
		}
		
		// [next page] ��ư ���
		if ((startPage + limit) <= pageCount) {
			str += "<a href='list.jsp?pageNum=" + (startPage + limit) + "'>����</a>";
		}
		
		return str;
	}
		
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public int getB_number() {
		return b_number;
	}
	public void setB_number(int b_number) {
		this.b_number = b_number;
	}
	public int getB_hit() {
		return b_hit;
	}
	public void setB_hit(int b_hit) {
		this.b_hit = b_hit;
	}
	public Timestamp getB_date() {
		return b_date;
	}
	public void setB_date(Timestamp b_date) {
		this.b_date = b_date;
	}
	public int getB_push() {
		return b_push;
	}
	public void setB_push(int b_push) {
		this.b_push = b_push;
	}
	public String getB_fname() {
		return b_fname;
	}
	public void setB_fname(String b_fname) {
		this.b_fname = b_fname;
	}
	public int getB_fsize() {
		return b_fsize;
	}
	public void setB_fsize(int b_fsize) {
		this.b_fsize = b_fsize;
	}
	public String getB_rfname() {
		return b_rfname;
	}
	public void setB_rfname(String b_rfname) {
		this.b_rfname = b_rfname;
	}
	public String getB_ip() {
		return b_ip;
	}
	public void setB_ip(String b_ip) {
		this.b_ip = b_ip;
	}
}
