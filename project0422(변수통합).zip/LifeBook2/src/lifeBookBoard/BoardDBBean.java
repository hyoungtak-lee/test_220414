package lifeBookBoard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDBBean {
	private static BoardDBBean instance = new BoardDBBean();
	public static BoardDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public int insertBoard(BoardBean board) throws Exception {
		Connection conn = null; 
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		
		int re = -1;
		int number;
		
		try {
			conn = getConnection();
			
			// �Խ��� ��ȣ ����
			sql = "select max(b_number) from board";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				number = rs.getInt(1)+1;
			} else {
				number = 1;
			}
			
			// �Խ��� ����
			sql = "insert into board(user_id, b_title, b_content, b_number, b_date, b_push, b_fname, b_fsize, b_rfname, b_ip)"
					+ " values(?,?,?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, board.getUser_id());
			pstmt.setString(2, board.getB_title());
			pstmt.setString(3, board.getB_content());
			pstmt.setInt(4, number);
			pstmt.setTimestamp(5, board.getB_date());
			pstmt.setInt(6, board.getB_push());
			pstmt.setString(7, board.getB_fname());
			pstmt.setInt(8, board.getB_fsize());
			pstmt.setString(9, board.getB_rfname());
			pstmt.setString(10, board.getB_ip());
			pstmt.executeUpdate();
			
			re = 1;
			
 			System.out.println("�߰� ����");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("�߰� ����");
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public ArrayList<BoardBean> listBoard(String pageNumber) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;
		
		int dbCount = 0;
		int absolutePage = 1;
		
		String sql = "select * from board order by b_number desc";
		String pageSetSql = "select count(b_number) from board";
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();
		
		try {
			conn = getConnection();
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			pageSet = stmt.executeQuery(pageSetSql);
			
			if (pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
			}
			
			if (dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
			}
			
			if (pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				
				while (count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					
					board.setUser_id(rs.getString(1));
					board.setB_title(rs.getString(2));
					board.setB_content(rs.getString(3));
					board.setB_number(rs.getInt(4));
					board.setB_hit(rs.getInt(5));
					board.setB_date(rs.getTimestamp(6));
					board.setB_push(rs.getInt(7));
					board.setB_fname(rs.getString(8));
					board.setB_fsize(rs.getInt(9));
					board.setB_rfname(rs.getString(10));
					board.setB_ip(rs.getString(11));
					
					boardList.add(board);
					
	 				if (rs.isLast()) {
						break;
					} else {
						rs.next();
					}
	 				
	 				count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return boardList;
	}
	
	public BoardBean getBoard(int b_number, boolean hitadd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		
		BoardBean board = null;
		
		try {
			conn = getConnection();
			
			if (hitadd == true) {
				sql = "update board set b_hit=b_hit+1 where b_number=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_number);
				pstmt.executeUpdate();
			}
			
			sql = "select * from board where b_number=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b_number);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				board = new BoardBean();
				board.setUser_id(rs.getString(1));
				board.setB_title(rs.getString(2));
				board.setB_content(rs.getString(3));
				board.setB_number(rs.getInt(4));
				board.setB_hit(rs.getInt(5));
				board.setB_date(rs.getTimestamp(6));
				board.setB_push(rs.getInt(7));
				board.setB_fname(rs.getString(8));
				board.setB_fsize(rs.getInt(9));
				board.setB_rfname(rs.getString(10));
				board.setB_ip(rs.getString(11));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return board;
	}
	
	public int deleteBoard(int b_number) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		
		int re = -1;
		
		try {
			conn = getConnection();
			sql = "select * from board where b_number=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b_number);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				sql = "delete from board where b_number=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, b_number);
				pstmt.executeUpdate();
				re = 1;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public int editBoard(BoardBean board) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		
		int re = -1;
		
		try {
			conn = getConnection();
			sql = "select * from board where b_number=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, board.getB_number());
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				sql = "update board set b_title=?, b_content=? where b_number=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, board.getB_title());
				pstmt.setString(2, board.getB_content());
				pstmt.setInt(3, board.getB_number());
				pstmt.executeUpdate();
				re = 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
	
	public ArrayList<BoardBean> getSearch(String searchField, String searchText) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();
		String sql = "select * from board where " + searchField.trim();
		
		try {
			if (searchText != null && !searchText.equals("")) {
				sql += " like '%" + searchText.trim() + "%' order by b_number desc";
			}
			
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				BoardBean board = new BoardBean();
				
				board.setUser_id(rs.getString(1));
				board.setB_title(rs.getString(2));
				board.setB_content(rs.getString(3));
				board.setB_number(rs.getInt(4));
				board.setB_hit(rs.getInt(5));
				board.setB_date(rs.getTimestamp(6));
				board.setB_push(rs.getInt(7));
				board.setB_fname(rs.getString(8));
				board.setB_fsize(rs.getInt(9));
				board.setB_rfname(rs.getString(10));
				board.setB_ip(rs.getString(11));
				
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}
	
	public BoardBean getFileName(int b_number) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select b_fname, b_rfname from board where b_number=?";
		BoardBean board = null;
		
		try {
			conn = getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b_number);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				board = new BoardBean();
				board.setB_fname(rs.getString(1));
				board.setB_rfname(rs.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return board;
	}
	
	public int recBoard(int b_number) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "update board set b_push=b_push+1 where b_number=?";
		int re = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b_number);
			pstmt.executeUpdate();
			
			re = 1;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return re;
	}
}
