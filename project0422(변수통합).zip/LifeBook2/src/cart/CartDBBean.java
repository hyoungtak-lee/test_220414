package cart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CartDBBean {
	private static CartDBBean instance = new CartDBBean();
	
	public static CartDBBean getinstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:/comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	private int getBookPrice(int bookNum) {
		String selectQuery = "select book_price from bookinfo where book_number=?";
		int re = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setInt(1, bookNum);

			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				re = rs.getInt(1);
			}
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return re;
	}
	
	public int insertCart(String user_id, int bookNum, int amount) {
		String insertQuery = "insert into cart values(?,?,?,?)";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int re = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setString(1, user_id);
			pstmt.setInt(2, bookNum);
			pstmt.setInt(3, getBookPrice(bookNum) * amount);
			pstmt.setInt(4, amount);

			re = pstmt.executeUpdate();
			
			re = 1;
			pstmt.close();
			conn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return re;
	}
}
