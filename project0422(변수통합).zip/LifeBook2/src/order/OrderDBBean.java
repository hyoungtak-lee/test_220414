package order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class OrderDBBean {

	private static OrderDBBean instance = new OrderDBBean();
	
	//OrderDBBean��ü ����
	public static OrderDBBean getInstance(){
		return instance;
	}
	
	//DBCP ��ü ����
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:/comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	//�ֹ����̺��� �ֹ����� �����ϴ� �޼ҵ�
	public int insertOrder(OrderBean order) {
		String insertQuery = "insert into order_table(ORDER_NUMBER, USER_ID, BOOK_NUMBER, ORDER_AMOUNT, ORDER_RECIPIENT, ORDER_PHONENUMBER, ORDER_ADDRESS) values(?,?,?,?,?,?,?)";
		int re = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(insertQuery);
			pstmt.setString(1, order.getOrder_number());
			pstmt.setString(2, order.getUser_id());
			pstmt.setInt(3, order.getBook_number());
			pstmt.setInt(4, order.getOrder_amount());
			pstmt.setString(5, order.getOrder_recipient());
			pstmt.setString(6, order.getOrder_phonenumber());
			pstmt.setString(7, order.getOrder_address());
			
			re = pstmt.executeUpdate();//���� ������ re=1�� ��
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	
	//��� �ֹ������� �������� ���̺�
	public ArrayList<OrderBean> getAllOrder() {
		String selectQuery = "select * from order_table";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<OrderBean> orders = null;
		OrderBean order = null;
		
		try {
			orders = new ArrayList<OrderBean>();
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			
			rs = pstmt.executeQuery();
			System.out.println(rs.next());
			
			while (rs.next()) {
				order = new OrderBean();
				order.setOrder_number(rs.getString(1));
				order.setUser_id(rs.getString(2));
				order.setBook_number(rs.getInt(3));
				order.setOrder_amount(rs.getInt(4));
				order.setOrder_date(rs.getTimestamp(5));
				orders.add(order);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return orders;
	}
	
	//�ֹ������� �Ű������� �ֹ������� �������� �޼ҵ�
	public OrderBean getOrder(String order_number) {
		String selectQuery = "select * from order_table where order_number=?";
		OrderBean order = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, order_number);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				order = new OrderBean();
				order.setOrder_number(rs.getString(1));
				order.setUser_id(rs.getString(2));
				order.setBook_number(rs.getInt(3));
				order.setOrder_amount(rs.getInt(4));
				order.setOrder_date(rs.getTimestamp(5));
				order.setOrder_statement(rs.getString("order_statement"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return order;
	}
	
	//�־�� �� �ֹ���ȣ�� �����ϴ� �޼ҵ�
	public long getTodayOrderNumber() {
		String selectQuery = "select count(*) from order_table where to_char(order_date,'yymmdd') = to_char(sysdate,'yymmdd')";
		long num = 0;
		
		//���� ��¥�� �ֹ���ȣ ���� ����
		LocalDateTime now = LocalDateTime.now();
		String pattenOfOrderNumber = DateTimeFormatter.ofPattern("yyMMdd0000").format(now);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				num = Long.parseLong(pattenOfOrderNumber) + rs.getInt(1) + 1;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return num;
	}
	public int updateOrderStatement(String orderNum, String statement) {
		String updateQuery = "update order_table set order_statement=? where order_number=?";
		int re = -1; // �������� �� ������ ����
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(updateQuery);
			pstmt.setString(1, statement);
			pstmt.setString(2, orderNum);
			
			re = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return re;
	}
}
