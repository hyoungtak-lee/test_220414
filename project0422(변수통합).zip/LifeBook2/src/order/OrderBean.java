package order;

import java.sql.Timestamp;

public class OrderBean {
	private String order_number;
	private int  book_number, order_amount;
	private String user_id, order_recipient, order_address, order_phonenumber, order_statement;
	private Timestamp order_date;
	
	public String getOrder_statement() {
		return order_statement;
	}
	public void setOrder_statement(String order_statement) {
		this.order_statement = order_statement;
	}
	public String getOrder_recipient() {
		return order_recipient;
	}
	public void setOrder_recipient(String order_recipient) {
		this.order_recipient = order_recipient;
	}
	public String getOrder_address() {
		return order_address;
	}
	public void setOrder_address(String order_address) {
		this.order_address = order_address;
	}
	public String getOrder_phonenumber() {
		return order_phonenumber;
	}
	public void setOrder_phonenumber(String order_phonenumber) {
		this.order_phonenumber = order_phonenumber;
	}
	public String getOrder_number() {
		return order_number;
	}
	public void setOrder_number(String order_number) {
		this.order_number = order_number;
	}
	public int getBook_number() {
		return book_number;
	}
	public void setBook_number(int book_number) {
		this.book_number = book_number;
	}
	public int getOrder_amount() {
		return order_amount;
	}
	public void setOrder_amount(int order_amount) {
		this.order_amount = order_amount;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public Timestamp getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Timestamp order_date) {
		this.order_date = order_date;
	}
	
}
