function check_ok(){
	
	if(reg_frm.user_pwd.value.length == 0){
		alert("패스워드는 반드시 입력해야 합니다.");
		reg_frm.user_pwd.focus();
		return;
	}
	
	if(reg_frm.user_pwd_check.value != reg_frm.user_pwd.value){
		alert("패스워드가 일치하지 않습니다.");
		reg_frm.user_pwd_check.focus();
		return;
	}
	
	if(reg_frm.user_tel2.value.length == 0){
		alert("전화번호를 써주세요.");
		reg_frm.user_tel2.focus();
		return;
	}
	
	if(isNaN(reg_frm.user_tel2.value)){
		alert("전화번호는 숫자만 입력가능합니다.");
		reg_frm.user_tel2.focus();
		return;
	}
	
	if(reg_frm.user_tel3.value.length == 0){
		alert("전화번호를 써주세요.");
		reg_frm.user_tel3.focus();
		return;
	}
	
	if(isNaN(reg_frm.user_tel3.value)){
		alert("전화번호는 숫자만 입력가능합니다.");
		reg_frm.user_tel3.focus();
		return;
	}
	
	if(reg_frm.user_address.value.length == 0){
		alert("주소를 써주세요.");
		reg_frm.user_address.focus();
		return;
	}
	
	if(isNaN(reg_frm.year.value)){
		alert("년도는 숫자만 입력가능합니다.");
		reg_frm.year.focus();
		return;
	}

	if(isNaN(reg_frm.date.value)){
		alert("일자는 숫자만 입력가능합니다.");
		reg_frm.date.focus();
		return;
	}
	
	document.reg_frm.submit();
}


function modify_check_ok(){
	if(document.mod_frm.user_pwd.value.length == 0){
		alert("패스워드는 반드시 입력해야 합니다.");
		mod_frm.user_pwd.focus();
		return;
	}	
	
	if(document.mod_frm.user_pwd.value != mod_frm.user_pwd_check.value){
		alert("패스워드가 일치하지 않습니다.");
		mod_frm.user_pwd_check.focus();
		return;
	}
		
	document.mod_frm.submit();
}

function withdraw_ok(){
	if(reg_frm.user_pwd.value.length == 0){
		alert("비밀번호를 써주세요.");
		reg_frm.user_pwd.focus();
		return;
	}
		
	document.reg_frm.submit();
}
