package LifeBook;

public class BookDBBean {

}
