package LifeBook;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDBBean {
	private static MemberDBBean instance=new MemberDBBean();
	public static MemberDBBean getInstance() {
		return instance;
	}
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	public int insertMember(MemberBean member) throws Exception {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="insert into membert values(?,?,?,?,?,?)";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getMem_uid());
			pstmt.setString(2, member.getMem_pwd());
			pstmt.setString(3, member.getMem_name());
			pstmt.setString(4, member.getMem_email());
			pstmt.setTimestamp(5, member.getMem_regdate());
			pstmt.setString(6, member.getMem_address());
			pstmt.executeUpdate();
			
			re=1;
 			pstmt.close();
 			conn.close();
 			
			System.out.println("�߰� ����");
		} catch (Exception e) {
			System.out.println("�߰� ����");
			e.printStackTrace();
		}
		
		return re;
	}
	
	public int confirmID(String id) throws Exception{
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select mem_uid from membert where mem_uid=?";
		int re=-1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) {
 				re=1;
			}else {
				re=-1;
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return re;
	}
	
	public int userCheck(String id, String pwd) throws Exception{
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select mem_pwd from membert where mem_uid=?";
		int re=-1;
		String db_mem_pwd;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
 			rs = pstmt.executeQuery();
 			
 			if(rs.next()) {
 				db_mem_pwd = rs.getString("mem_pwd");
 				
 				if (db_mem_pwd.equals(pwd)) {
					re=1;
				}else {
					re=0;
				}
 			}else {
 				re=-1;
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return re;
	}
	
	public MemberBean getMember(String id) throws Exception{
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql="select * from membert where mem_uid=?";
		MemberBean member=null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
 			rs = pstmt.executeQuery();
 			
 			if (rs.next()) {
				member = new MemberBean();
				member.setMem_uid(rs.getString("mem_uid"));
				member.setMem_pwd(rs.getString("mem_pwd"));
				member.setMem_name(rs.getString("mem_name"));
				member.setMem_email(rs.getString("mem_email"));
				member.setMem_regdate(rs.getTimestamp("mem_regdate"));
				member.setMem_address(rs.getString("mem_address"));
			}
 			
 			rs.close();
 			pstmt.close();
 			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return member;
	}
	
	public int updateMember(MemberBean member) throws Exception {
		Connection conn=null;
		PreparedStatement pstmt=null;
		int re=-1;
		
		String sql="update memberT set mem_pwd=?, mem_email=?, mem_address=? where mem_uid=?";
		
		try {
			conn=getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getMem_pwd());
			pstmt.setString(2, member.getMem_email());
			pstmt.setString(3, member.getMem_address());
			pstmt.setString(4, member.getMem_uid());
			re = pstmt.executeUpdate();
			
			System.out.println("���� ����");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("���� ����");
		}
		
		return re;
	}
}
