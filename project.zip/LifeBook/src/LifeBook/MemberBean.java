package LifeBook;


public class MemberBean {
	private String user_uid;
	private String user_pwd;
	private int user_phonenumber;
	private String user_address;
	private int adminYN;
	public String getUser_uid() {
		return user_uid;
	}
	public void setUser_uid(String user_uid) {
		this.user_uid = user_uid;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public int getUser_phonenumber() {
		return user_phonenumber;
	}
	public void setUser_phonenumber(int user_phonenumber) {
		this.user_phonenumber = user_phonenumber;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public int getAdminYN() {
		return adminYN;
	}
	public void setAdminYN(int adminYN) {
		this.adminYN = adminYN;
	}
	
	
}
