package area;

public class Circle2 {
	int a;
	public double process(){
		return a*a*3.14;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}


}
