package area;

public class Circle {
	int a;
	public double process(){
		return a*a*Math.PI;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
}
