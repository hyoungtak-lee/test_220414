package area;

public class Rectangle {
	public int process(int a, int b) {
		return a*b;
	}
}
