package area;

public class GuGuDan {
	public int process(int i, int j) {
		return i*j;
	}
}
