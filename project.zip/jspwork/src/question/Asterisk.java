package question;

public class Asterisk {
	private int a;
	public String process(int a) {
		StringBuffer x = new StringBuffer();
		for (int i = 0; i < a; i++) {
			for (int j = 0; j < a-i; j++) {
				x.append("*");
			}
			x.append("<br>");
		}
		return x.toString();
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	
}
