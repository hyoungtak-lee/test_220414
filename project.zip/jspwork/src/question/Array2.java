package question;

public class Array2 {
	private int a, b, c, d, e;
	public String process(int a, int b, int c, int d, int e) {
		int array[] = {a, b, c, d, e};
		StringBuffer y= new StringBuffer();
		
		for (int i = 0; i < array.length; i++) {
			if (array[i]%3==0) {
				y.append(array[i]+" ");
			}
		}
		return y.toString();
	}
	
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int getC() {
		return c;
	}
	public void setC(int c) {
		this.c = c;
	}
	public int getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}
	public int getE() {
		return e;
	}
	public void setE(int e) {
		this.e = e;
	}
}
