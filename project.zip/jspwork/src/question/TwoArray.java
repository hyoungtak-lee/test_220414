package question;

public class TwoArray {
	private int a;
	
	public String process(int a) {
		StringBuffer strBuf = new StringBuffer();
		
		int[][] array = new int [a][a];
		
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j]=(int)(Math.random()*10+1);
				strBuf.append(array[i][j]+" ");
			}
			strBuf.append("<br>");
		}
		return strBuf.toString();
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
	
	
}
