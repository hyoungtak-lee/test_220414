package question;

public class ThreeSixNine {
	private int a;
	public String process(int a) {
		String result="";
		if (a/10==3 || a/10==6 || a/10==9) {
			if (a%10==3 || a%10==6 || a%10==9) {
				result="�ڼ�¦¦";
			}else {
				result="�ڼ�¦";
			}
		}else if (a%10==3 || a%10==6 || a%10==9) {
			result="�ڼ�¦";
		}else {
			result="�ڼ� ����";
		}
		return result;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
}
