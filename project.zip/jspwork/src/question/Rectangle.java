package question;

public class Rectangle {
	private int x;
	private int y;
	
	public String process(int i, int y) {
		String result="";
		if (i>=100 && i<=200 && y>=100 && y<=200) {
			result="�� �簢�� �ȿ� �ֽ��ϴ�.";
		}else {
			result="�� �簢�� �ۿ� �ֽ��ϴ�.";
		}
		return result;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
}
