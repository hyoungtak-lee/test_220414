package question;

public class Three {
	private int num;
	public String process(int i) {
		String result="";
		if (i%3==0) {
			result="3�� ����Դϴ�.";
		}else {
			result="3�� ����� �ƴմϴ�.";
		}
		
		return result;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}
