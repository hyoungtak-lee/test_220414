package question;

public class Won2dollar {
	private int won;
	public double process(int i) {
		return (double)i/1200;
	}
	public int getWon() {
		return won;
	}
	public void setWon(int won) {
		this.won = won;
	}
}
