package question;

public class Season {
	private int month;
	public int process() {
		return month;
	}
	public int getA() {
		return month;
	}
	public void setA(int month) {
		this.month = month;
	}
}
