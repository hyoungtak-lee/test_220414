package question;

import java.util.Random;

public class Array4 {
	private int a;

	public String process(int a) {
		StringBuffer strBuf = new StringBuffer();
		int array[]=new int[a];
		Random rand = new Random();
		for (int i = 0; i < array.length; i++) {
			array[i] = rand.nextInt(100)+1;
			for (int j = 0; j < i; j++) {
				if (array[i]==array[j]) {
					i--;
					break;
				}
			}
		}
		
		for (int i = 0; i < array.length; i++) {
			if (i==0) {
				strBuf.append(array[i]+" ");
			}else {
				if (i%10==0) {
					strBuf.append("<br>");
				}
				strBuf.append(array[i]+" ");
			}
		}
		return strBuf.toString();
	}
	
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}


}
