package question;

public class EvenNumber {
	private int a;
	public int process(int a) {
		int b=0;
		for (int i = 1; i <= a; i++) {
			if (i%2==0) {
				b+=i;
			}
		}
		return b;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
}
