package question;

import java.util.Random;

public class Array3 {
	private int a;

	public String process(int a) {
		StringBuffer strBuf = new StringBuffer();
		Random rand = new Random();
		for (int i = 1; i <= a; i++) {
			int random = rand.nextInt(101)+1;
			strBuf.append(random+" ");
			if (i%10==0) {
				strBuf.append("<br>");
			}
		}
		return strBuf.toString();
	}
	
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
}
