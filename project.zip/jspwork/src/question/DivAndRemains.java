package question;

public class DivAndRemains {
	private int num;
	public String process(int i) {
		String result="";
		int a=i/10;
		int b=i%10;
		
		if (a==b) {
			result="�ڸ��� �����ϴ�.";
		}else {
			result="�ڸ��� �ٸ��ϴ�.";
		}
		return result;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	} 
}
