package LifeBook;

public class BookBean {
	
	
}
