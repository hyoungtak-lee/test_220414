package userInfo;

import java.sql.Timestamp;

public class UserInfoBean {
	private String user_id;
	private String user_pwd;
	private String user_address;
	private int adminYN;
	private int user_mileage;
	private String user_phonenumber;
	private Timestamp user_birthdate;
	private String user_name;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pwd() {
		return user_pwd;
	}
	public void setUser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public int getAdminYN() {
		return adminYN;
	}
	public void setAdminYN(int adminYN) {
		this.adminYN = adminYN;
	}
	public int getUser_mileage() {
		return user_mileage;
	}
	public void setUser_mileage(int user_mileage) {
		this.user_mileage = user_mileage;
	}
	public String getUser_phonenumber() {
		return user_phonenumber;
	}
	public void setUser_phonenumber(String user_phonenumber) {
		this.user_phonenumber = user_phonenumber;
	}
	public Timestamp getUser_birthdate() {
		return user_birthdate;
	}
	public void setUser_birthdate(Timestamp user_birthdate) {
		this.user_birthdate = user_birthdate;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	
	
	
		
}
