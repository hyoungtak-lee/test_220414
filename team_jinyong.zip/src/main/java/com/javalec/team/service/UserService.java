package com.javalec.team.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.team.dto.UserDto;


public interface UserService {
	public ArrayList<UserDto> loginYn(HashMap<String, String> param);
	
	public void write(HashMap<String, String> param);
	
	public void outUser(HashMap<String, String> param);
	
	public UserDto checkId(HashMap<String, String> param);
	
	public UserDto confirmUserId(HashMap<String, String> param);
	
	public UserDto tryToFindId(HashMap<String, String> param);
	
	public UserDto tryToFinPwd(HashMap<String, String> param);
	
}

