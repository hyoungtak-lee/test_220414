package com.javalec.team.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.team.dao.UserDao;
import com.javalec.team.dto.UserDto;

@Service("UserService")
public class UserServiceImpl implements UserService{
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public ArrayList<UserDto> loginYn(@RequestParam HashMap<String, String> param) {
		
		UserDao dao = sqlSession.getMapper(UserDao.class);
		ArrayList<UserDto> dtos = dao.loginYn(param);
		
		return dtos;
	}

	@Override
	public void write(@RequestParam HashMap<String, String> param) {
//		System.out.println("@@@### UserServiceImpl.write() start");
		
		UserDao dao = sqlSession.getMapper(UserDao.class);
		dao.write(param);
		
	}

	@Override
	public void outUser(HashMap<String, String> param) {
		UserDao dao = sqlSession.getMapper(UserDao.class);
		dao.outUser(param);
		
	}
	
	
	@Override
	public UserDto confirmUserId(@RequestParam HashMap<String, String> param) {
		UserDao dao = sqlSession.getMapper(UserDao.class);
		UserDto dto = dao.confirmUserId(param);
		
		return dto;
		
	}
	
	@Override
	public UserDto tryToFindId(@RequestParam HashMap<String, String> param) {
		
		UserDao dao = sqlSession.getMapper(UserDao.class);
		UserDto u_id = dao.tryToFindId(param);
		
		return u_id;
	}

	@Override
	public UserDto tryToFinPwd(HashMap<String, String> param) {
		
		UserDao dao = sqlSession.getMapper(UserDao.class);
		UserDto u_pwd = dao.tryToFinPwd(param);
		
		return u_pwd;
	}

	@Override
	public UserDto checkId(HashMap<String, String> param) {
	
		UserDao dao = sqlSession.getMapper(UserDao.class);
		UserDto result = dao.checkId(param);
		return result;
	}

	



}
